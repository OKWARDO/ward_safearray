#include "ConvertInto.hpp"
#include<string>
#include<cstring>


ConvertInto::ConvertInto()
{
}


ConvertInto::ConvertIntoPerformConversion(char * string)
{
}

ConvertInto::~ConvertInto()
{
}

~ConvertInto()
{
}
