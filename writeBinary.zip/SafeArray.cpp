#include "SafeArray.hpp"

SafeArray::
SafeArrayDestroy(psa)
{
}
